'''
Data Project P.3
Mateo C. and Benjamin G. 
'''
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt
 
 #gets countries to create into objects
objects = ('Singapore', 'China', 'Korea', 'Japan', 'Liechtenstein', 'Switzerland', 'Netherlands', 'Estonia', 'Finland', 'Canada', 'France', 'United Kingdom', 'Iceland', 'Italy', 'Spain', 'Russain Federation', 'United States', 'Lithuania', 'Sweden', 'Hungary', 'United Arab Emirates', 'Kazakhstan', 'Thailand', 'Mexico', 'Colombia', 'Peru')
y_pos = np.arange(len(objects))
#gets amount of musicians and creates them into performances
performance = [3,105,50,95,.017,3,3,.8,2,20,47,.0003,44,28,28,48,3,3,6,7,8,65,20,58,5]

plt.bar(y_pos, performance,width=0.8, align='center', alpha=1)
plt.xticks(y_pos, objects, rotation=90)
plt.ylabel('Number of Musicians(In Millions)')
plt.title('Number of Musicians Around the World')
 
plt.show()