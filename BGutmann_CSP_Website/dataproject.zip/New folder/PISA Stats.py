'''
Data Project P.3
Mateo C. and Benjamin G. 
'''
import matplotlib.pyplot as plt; plt.rcdefaults()
import numpy as np
import matplotlib.pyplot as plt

 
objects = ('Singapore', 'China', 'Korea', 'Japan', 'Liechtenstein', 'Switzerland', 'Netherlands', 'Estonia', 'Finland', 'Canada', 'France', 'United Kingdom', 'Iceland', 'Italy', 'Spain', 'Russain Federation', 'United States', 'Lithuania', 'Sweden', 'Hungary', 'United Arab Emirates', 'Kazakhstan', 'Thailand', 'Mexico', 'Colombia', 'Peru')
y_pos = np.arange(len(objects))
performance = [573,568,554,536,535,531,523,521,519,518,495,494,493,485,484,482,481,479,478,477,434,432,427,413,376,368]
 
plt.bar(y_pos, performance, align='center', alpha=1)
plt.xticks(y_pos, objects, rotation=90)
plt.ylabel('Scores')
plt.title('PISA Scores In 2012')
 
plt.show()